amps - are my packages safe
Distribution auto detection script that scans for locally installed packages and checks if there are any known security vulnerabilities for them. Useful for servers and preventing any entry points for harmful intent.
Done: Arch based distros
Todo: Ubuntu/Check specific package versions for potential updates/add well known distros
